const stats = [
  { value: "7,500+", label: "Facebook Followers", color: "blue" },
  { value: "4,500+", label: "TikTok Followers", color: "pink" },
  { value: "932K", label: "Views / 7 ມື້", color: "lime" },
  { value: "608K", label: "Top Performing Video", color: "orange" },
];

const series = [
  {
    no: "01",
    title: "ເລື່ອງຂອງເດີ່ນຫຍ້າ",
    english: "THE PITCH STORIES",
    image: "/media/series-pitch-story.webp",
    className: "pitch",
    summary: "ຂ່າວບານ, Transfer, ນັກເຕະ, ສະໂມສອນ ແລະສະຖິຕິທີ່ແຟນບານຄວນຮູ້.",
    formats: ["News", "Transfer", "Profile", "Stats"],
  },
  {
    no: "02",
    title: "ເກມເດືອດ",
    english: "HOT MATCH SHOW",
    image: "/media/series-hot-match.webp",
    className: "hot",
    summary: "ພຣີວິວ Big Match, Reaction ຫຼັງເກມ, Hot Take ແລະວິເຄາະຈຸດຕັດສິນເກມ.",
    formats: ["Big Match", "Reaction", "Tactics", "Hot Take"],
  },
  {
    no: "03",
    title: "ບານປາຍຫຼັງເກມ",
    english: "FANS AFTER THE MATCH",
    image: "/media/series-fan.webp",
    className: "fan",
    summary: "ພື້ນທີ່ໃຫ້ແຟນບານຕອບຄຳຖາມ, Vote, ທາຍຜົນ ແລະແລກປ່ຽນຄວາມເຫັນຫຼັງເກມ.",
    formats: ["Poll", "Question", "Prediction", "Community"],
  },
  {
    no: "04",
    title: "ເກມປ່ຽນໂລກ",
    english: "THE GAME THAT CHANGED THE WORLD",
    image: "/media/series-world-change.webp",
    className: "world",
    summary: "ຍ້ອນຄືນເກມ, ບຸກຄົນ ແລະເຫດການສຳຄັນທີ່ປ່ຽນປະຫວັດສາດບານເຕະ.",
    formats: ["History", "World Cup", "Iconic Moment", "Legacy"],
  },
];

const sponsorOptions = [
  {
    title: "Series Partner",
    text: "ໃຫ້ Brand ເປັນຜູ້ຮ່ວມຫຼັກຂອງ 1 ໃນ 4 ລາຍການ ແລະປາກົດຢ່າງຕໍ່ເນື່ອງ.",
  },
  {
    title: "Big Match Partner",
    text: "ເຊື່ອມ Brand ກັບເກມໃຫຍ່ຜ່ານ Preview, Live Moment, Reaction ແລະຜົນຫຼັງເກມ.",
  },
  {
    title: "Content Integration",
    text: "ວາງສິນຄ້າ, Logo ຫຼື Message ໃນຄອນເທນໃຫ້ເປັນທຳມະຊາດ ແລະເໝາະກັບແຟນບານ.",
  },
  {
    title: "Custom Campaign",
    text: "ອອກແບບ Campaign ຕາມເປົ້າໝາຍຂອງ Brand: Reach, Awareness, Engagement ຫຼື Activation.",
  },
];

export default function Home() {
  return (
    <main>
      <header className="site-header">
        <a className="brand" href="#top" aria-label="All in Football home">
          <span className="brand-mark">AI</span>
          <span className="brand-copy"><b>ALL IN</b><small>FOOTBALL MEDIA</small></span>
        </a>
        <nav aria-label="Main navigation">
          <a href="#about">ກ່ຽວກັບເຮົາ</a>
          <a href="#series">ລາຍການ</a>
          <a href="#proof">ຜົນງານ</a>
          <a className="nav-cta" href="#contact">ຮ່ວມງານ</a>
        </nav>
      </header>

      <section className="hero" id="top">
        <div className="hero-grid" aria-hidden="true" />
        <div className="hero-copy">
          <div className="eyebrow"><span /> LAO FOOTBALL MEDIA</div>
          <h1>ALL IN<br /><em>FOOTBALL</em></h1>
          <h2>ບານປາຍທຸກເກມ</h2>
          <p>ສື່ບານເຕະຂອງລາວທີ່ນຳສະເໜີຂ່າວ, ຄວາມບັນເທີງ, ຄວາມຮູ້ ແລະສຽງຂອງແຟນບານ — ໄວ, ມ່ວນ ແລະເຂົ້າໃຈງ່າຍ.</p>
          <div className="hero-actions">
            <a className="button primary" href="#series">ເບິ່ງ 4 ລາຍການ <span>↓</span></a>
            <a className="button secondary" href="#contact">ຕິດຕໍ່ຮ່ວມງານ <span>↗</span></a>
          </div>
        </div>
        <div className="hero-art" aria-hidden="true">
          <div className="ball"><span>ALL IN</span></div>
          <div className="speed-line one" />
          <div className="speed-line two" />
          <div className="signal">LIVE<br /><strong>24/7</strong></div>
        </div>
        <div className="platform-strip">
          <span>FACEBOOK</span><i>•</i><span>TIKTOK</span><i>•</i><span>REELS</span><i>•</i><span>SHORT VIDEO</span><i>•</i><span>FOOTBALL COMMUNITY</span>
        </div>
      </section>

      <section className="stats" aria-label="All in Football audience figures">
        {stats.map((stat) => (
          <article className={stat.color} key={stat.label}>
            <strong>{stat.value}</strong>
            <span>{stat.label}</span>
          </article>
        ))}
      </section>

      <section className="about section" id="about">
        <div className="section-label">01 / ABOUT ALL IN</div>
        <div className="about-layout">
          <h2>ບໍ່ໄດ້ພຽງແຕ່<br />ລາຍງານຂ່າວ.<br /><em>ເຮົາສ້າງບົດສົນທະນາ.</em></h2>
          <div className="about-copy">
            <p>ALL IN ສ້າງຄອນເທນສຳລັບແຟນບານລາວ ຕັ້ງແຕ່ຂ່າວດ່ວນ, Big Match, ປະຫວັດສາດບານເຕະ ຈົນເຖິງເກມທີ່ເປີດໃຫ້ແຟນບານຮ່ວມຕອບ.</p>
            <div className="about-points">
              <span>01 <b>ຂ່າວໄວ</b></span>
              <span>02 <b>ວິເຄາະງ່າຍ</b></span>
              <span>03 <b>ສົນທະນາຈິງ</b></span>
              <span>04 <b>ສ້າງຄອມມູນິຕີ</b></span>
            </div>
          </div>
        </div>
      </section>

      <section className="series-section section" id="series">
        <div className="section-heading">
          <div><span className="section-label">02 / ORIGINAL SERIES</span><h2>4 ລາຍການຫຼັກ<br />ຂອງ ALL IN</h2></div>
          <p>ແຕ່ລະລາຍການມີໜ້າທີ່ຊັດເຈນ: ຂ່າວ, ເກມໃຫຍ່, ສຽງແຟນບານ ແລະເລື່ອງລາວທີ່ປ່ຽນໂລກບານເຕະ.</p>
        </div>
        <div className="series-grid">
          {series.map((item) => (
            <article className={`series-card ${item.className}`} key={item.no}>
              <div className="series-visual">
                <img src={item.image} alt={`${item.title} series artwork`} />
                <span className="series-no">{item.no}</span>
              </div>
              <div className="series-info">
                <small>{item.english}</small>
                <h3>{item.title}</h3>
                <p>{item.summary}</p>
                <div className="format-tags">{item.formats.map((format) => <span key={format}>{format}</span>)}</div>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="content-engine section">
        <div className="engine-title">
          <span className="section-label">03 / CONTENT ENGINE</span>
          <h2>1 ໄອເດຍ.<br /><em>ຫຼາຍ Platform.</em></h2>
          <p>ຄອນເທນຫຼັກ 1 ຊິ້ນ ຖືກຕໍ່ຍອດໃຫ້ເໝາະກັບພຶດຕິກຳຂອງແຟນບານໃນແຕ່ລະ Platform.</p>
        </div>
        <div className="engine-flow">
          <article className="source"><small>ORIGINAL</small><strong>Record / Research</strong><span>2–5 min main content</span></article>
          <div className="flow-arrow">→</div>
          <div className="outputs">
            <article><b>01</b><strong>TikTok</strong><span>Hook + Short Video</span></article>
            <article><b>02</b><strong>Facebook Reel</strong><span>Short Video + Caption</span></article>
            <article><b>03</b><strong>Facebook Post</strong><span>Graphic + Key Point</span></article>
            <article><b>04</b><strong>Community</strong><span>Poll + Question</span></article>
          </div>
        </div>
      </section>

      <section className="proof section" id="proof">
        <div className="proof-heading">
          <div><span className="section-label">04 / REAL PERFORMANCE</span><h2>ຜົນງານຈິງ.<br />ກວດສອບໄດ້.</h2></div>
          <div className="proof-total"><strong>1.1M+</strong><span>Views ລວມຈາກ 9 ຄລິບຕົວຢ່າງ</span></div>
        </div>
        <div className="proof-image"><img src="/media/proof-views.webp" alt="All in Football real content view screenshots" /></div>
        <div className="audience-row">
          <div><strong>80%</strong><span>ຜູ້ຊົມເປັນຜູ້ຊາຍ</span></div>
          <div><strong>79.8%</strong><span>ອາຍຸ 18–34 ປີ</span></div>
          <div><strong>8,428</strong><span>Shares / 7 ມື້</span></div>
          <div><strong>ທົ່ວປະເທດ</strong><span>ຖານຜູ້ຊົມທົ່ວ ສປປ ລາວ</span></div>
        </div>
        <p className="data-note">Performance screenshots ແລະ Analytics ຈາກ TikTok / Facebook · ຂໍ້ມູນຜົນງານ June 2026</p>
      </section>

      <section className="sponsor section" id="sponsor">
        <div className="section-heading">
          <div><span className="section-label">05 / WORK WITH ALL IN</span><h2>ໃຫ້ Brand ຂອງທ່ານ<br />ຢູ່ໃນເກມ</h2></div>
          <p>ເຮົາອອກແບບການຮ່ວມງານຕາມເປົ້າໝາຍຂອງ Brand ໂດຍເນັ້ນຄວາມເໝາະສົມ, ຄວາມໜ້າເຊື່ອຖື ແລະປະສົບການຂອງແຟນບານ.</p>
        </div>
        <div className="sponsor-grid">
          {sponsorOptions.map((option, index) => (
            <article key={option.title}><span>{String(index + 1).padStart(2, "0")}</span><h3>{option.title}</h3><p>{option.text}</p><a href="#contact">ສົນໃຈຮ່ວມງານ ↗</a></article>
          ))}
        </div>
        <div className="brand-safe"><span>✓</span><div><strong>BRAND-SAFE FOOTBALL CONTENT</strong><p>ALL IN ບໍ່ຮັບໂຄສະນາພະນັນ.</p></div></div>
      </section>

      <section className="contact" id="contact">
        <div className="contact-copy">
          <span className="section-label">06 / CONTACT</span>
          <h2>ມາສ້າງຄອນເທນ<br />ທີ່ແຟນບານຢາກເບິ່ງ</h2>
          <p>ສົ່ງເປົ້າໝາຍຂອງ Brand ມາໃຫ້ເຮົາ. ALL IN ຈະຊ່ວຍເລືອກລາຍການ, Platform ແລະມຸມຄອນເທນທີ່ເໝາະສົມ.</p>
          <div className="contact-actions">
            <a className="button primary" href="https://wa.me/8562094407688" target="_blank" rel="noreferrer">WhatsApp <span>↗</span></a>
            <a className="button secondary" href="https://m.me/61555652292417" target="_blank" rel="noreferrer">Facebook Messenger <span>↗</span></a>
            <a className="button tiktok" href="https://www.tiktok.com/@allin_football1?lang=en" target="_blank" rel="noreferrer">TikTok <span>↗</span></a>
          </div>
        </div>
        <div className="contact-card">
          <small>DIRECT CONTACT</small>
          <strong>+856 20 9440 7688</strong>
          <span>Khamhoung · ALL IN Football Media</span>
          <div className="social-links">
            <a href="https://www.facebook.com/profile.php?id=61555652292417" target="_blank" rel="noreferrer">Facebook Page <span>↗</span></a>
            <a href="https://www.tiktok.com/@allin_football1?lang=en" target="_blank" rel="noreferrer">TikTok @allin_football1 <span>↗</span></a>
          </div>
        </div>
      </section>

      <footer>
        <a className="brand" href="#top"><span className="brand-mark">AI</span><span className="brand-copy"><b>ALL IN</b><small>FOOTBALL MEDIA</small></span></a>
        <p>ຂ່າວ · ຄວາມບັນເທີງ · ຄວາມຮູ້ · ຄອມມູນິຕີ</p>
        <a href="#top">BACK TO TOP ↑</a>
      </footer>
    </main>
  );
}
